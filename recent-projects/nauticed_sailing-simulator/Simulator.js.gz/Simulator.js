(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Simulator_atlas_", frames: [[1746,1177,38,37],[1746,1216,38,37],[1633,1059,148,116],[722,1002,560,160],[202,1456,420,90],[1104,1332,680,90],[2009,547,20,20],[722,840,680,160],[684,1122,20,20],[1378,1149,20,20],[1633,897,400,160],[1378,1171,20,20],[1184,1164,92,92],[1284,1002,92,252],[1933,1059,60,191],[1378,1002,14,145],[961,1512,341,109],[1104,1266,295,63],[1304,1538,342,107],[695,1666,296,61],[1401,1424,335,112],[1728,1653,289,66],[624,1512,335,112],[404,1666,289,66],[1404,582,227,748],[437,1368,480,86],[919,1424,480,86],[482,1122,200,40],[0,1122,480,160],[722,0,580,580],[1304,0,580,580],[0,1284,435,121],[993,1713,166,86],[0,1604,198,87],[1886,498,95,78],[1933,1252,95,78],[1933,1332,95,78],[1983,498,52,47],[722,582,680,256],[919,1368,148,37],[1648,1538,100,37],[774,1456,126,37],[404,1548,100,37],[624,1456,148,37],[1161,1713,166,86],[0,1693,198,87],[1329,1713,166,83],[0,1407,200,195],[202,1548,200,180],[1886,297,145,199],[1886,0,145,295],[1786,1059,145,295],[1786,1356,145,295],[2033,0,12,22],[1995,1059,49,94],[1633,1177,67,134],[1995,1155,42,84],[1702,1177,42,84],[1633,582,410,313],[2019,1412,24,306],[482,1266,620,100],[993,1684,660,27],[404,1626,660,38],[1066,1647,660,35],[482,1164,700,100],[1983,547,24,18],[1702,1263,40,40],[1744,1263,40,40],[202,1407,200,40],[0,0,720,1120]]}
];


// symbols:



(lib.CachedBmp_81 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_80 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_95 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_94 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_93 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_92 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_74 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_91 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_72 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_70 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_90 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_76 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_67 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_66 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_65 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_64 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_63 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_62 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_61 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_60 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_59 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_58 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_57 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_56 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_55 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_53 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_51 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_86 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_88 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_48 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_47 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_46 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_45 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_44 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_43 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_42 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_41 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_40 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_35 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_34 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_33 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_32 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_31 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_30 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_28 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_38 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_37 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_36 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_24 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_23 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_21 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_20 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_19 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_18 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_14 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_13 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_12 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_11 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_8 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_7 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_5 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_84 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_83 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_82 = function() {
	this.initialize(ss["Simulator_atlas_"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txtHit = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_95();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txtHit, new cjs.Rectangle(0,0,74,58), null);


(lib.tooltip = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{mainWinch:0,jibWinch:1,helm:2,eMeter:3,notifierFix:4,wind:5,navigatorHit:6,rudder:7,mainSailMirror:8,mainSail:9,jibSailMirror:10,jibSail:11,txtSpeedHit:12,txtHeelHit:13,txtWindHit:14,txtHdgHit:15,txtDepthHit:16});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(17));

	// txt
	this.txt = new cjs.Text("Controls the main sail. Adjust the number of turns on the winch to maximize the speed of the boat.", "14px 'Arial'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 18;
	this.txt.lineWidth = 186;
	this.txt.parent = this;
	this.txt.setTransform(128.5,385);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1).to({x:45.5,text:"Controls the jib sail. Adjust the number of turns on the winch to maximize the speed of the boat."},0).wait(1).to({x:17,y:475,text:"Click to steer the boat to port or starboard.  Upon release, the boat will return to the upright position. The wind angle and heading will have changed accordingly.",lineWidth:326},0).wait(1).to({y:450,text:"Indicates how well your sails are set for the specific wind angle."},0).wait(1).to({x:132.5,y:474,text:"This is the \"Point of Sail\" angle.",lineWidth:196},0).wait(1).to({x:47,y:417,text:"The direction of the wind relative to the boat. Click to increase or decrease the speed of the wind.",lineWidth:266},0).wait(1).to({y:427,text:"Angles show the direction of the wind relative to the boat."},0).wait(1).to({text:"The Rudder. Steer the boat by clicking the split center helm button below."},0).wait(1).to({y:417,text:"The main sail can be adjusted by cranking on the port winch. Set the sails to maximize the speed of the boat."},0).wait(2).to({text:"The jib sail can be adjusted by cranking on the starboard winch. Set the sails to maximize the speed of the boat."},0).wait(2).to({y:427,text:"The speed of the boat is maximized when the sails are set correctly."},0).wait(1).to({y:434,text:"The boat heels over when on a close haul."},0).wait(1).to({y:427,text:"The speed of the wind can be adjusted by clicking on the red wind triangle."},0).wait(1).to({y:434,text:"The compass heading."},0).wait(1).to({y:417,text:"Indicates the depth of the water below the surface. This changes to simulate the boat is moving."},0).wait(1));

	// bg
	this.instance = new lib.CachedBmp_90();
	this.instance.setTransform(121.5,380,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_76();
	this.instance_1.setTransform(111.5,414.45,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_70();
	this.instance_2.setTransform(238.5,414.45,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_91();
	this.instance_3.setTransform(10,470,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_72();
	this.instance_4.setTransform(175,460,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_92();
	this.instance_5.setTransform(10,445,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_74();
	this.instance_6.setTransform(175,490,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_93();
	this.instance_7.setTransform(125.5,458.45,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_94();
	this.instance_8.setTransform(40,402,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1,p:{x:111.5,y:414.45}},{t:this.instance,p:{x:121.5}}]}).to({state:[{t:this.instance_2},{t:this.instance,p:{x:38.5}}]},1).to({state:[{t:this.instance_4},{t:this.instance_3}]},1).to({state:[{t:this.instance_6},{t:this.instance_5}]},1).to({state:[{t:this.instance_1,p:{x:115.5,y:475.95}},{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).wait(12));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(10,380,340,170);


(lib.sliderDragger = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.CachedBmp_67();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sliderDragger, new cjs.Rectangle(0,0,46,46), null);


(lib.sliderBg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.CachedBmp_66();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sliderBg, new cjs.Rectangle(0,0,46,126), null);


(lib.rudder = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_64();
	this.instance.setTransform(-3.5,-3.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.instance_1 = new lib.CachedBmp_65();
	this.instance_1.setTransform(-15,-15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rudder, new cjs.Rectangle(-15,-15,30,95.5), null);


(lib.mainSailMirror = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_62();
	this.instance.setTransform(-2.85,-3.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.instance_1 = new lib.CachedBmp_63();
	this.instance_1.setTransform(-14.35,-15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainSailMirror, new cjs.Rectangle(-14.3,-15,170.5,54.5), null);


(lib.mainSail = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_60();
	this.instance.setTransform(-143.85,-3.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.instance_1 = new lib.CachedBmp_61();
	this.instance_1.setTransform(-155.35,-15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainSail, new cjs.Rectangle(-155.3,-15,171,53.5), null);


(lib.jibSailMirror = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_58();
	this.instance.setTransform(-2.55,-7.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.instance_1 = new lib.CachedBmp_59();
	this.instance_1.setTransform(-14.05,-19.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.jibSailMirror, new cjs.Rectangle(-14,-19.2,167.5,56), null);


(lib.jibSail = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_56();
	this.instance.setTransform(-139.9,-7.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.instance_1 = new lib.CachedBmp_57();
	this.instance_1.setTransform(-151.4,-19.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.jibSail, new cjs.Rectangle(-151.4,-19.2,167.5,56), null);


(lib.boat = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// bg
	this.instance = new lib.CachedBmp_55();
	this.instance.setTransform(-2.8,-3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.boat, new cjs.Rectangle(-2.8,-3,113.5,374), null);


(lib.notifierTacking = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// txt
	this.instance = new lib.CachedBmp_53();
	this.instance.setTransform(0,18,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// bg
	this.instance_1 = new lib.CachedBmp_88();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.notifierTacking, new cjs.Rectangle(0,0,240,80), null);


(lib.notifierGybing = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// txt
	this.instance = new lib.CachedBmp_51();
	this.instance.setTransform(0,18,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// bg
	this.instance_1 = new lib.CachedBmp_88();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.notifierGybing, new cjs.Rectangle(0,0,240,80), null);


(lib.notifierFix = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// txt
	this.txt = new cjs.Text("", "13px 'Arial'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.textAlign = "center";
	this.txt.lineHeight = 17;
	this.txt.lineWidth = 96;
	this.txt.parent = this;
	this.txt.setTransform(50,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// bg
	this.instance = new lib.CachedBmp_86();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.notifierFix, new cjs.Rectangle(0,0,100,20), null);


(lib.notifier = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// txt
	this.txt = new cjs.Text("", "35px 'Arial'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.textAlign = "center";
	this.txt.lineHeight = 41;
	this.txt.lineWidth = 236;
	this.txt.parent = this;
	this.txt.setTransform(120,20);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// bg
	this.instance = new lib.CachedBmp_88();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.notifier, new cjs.Rectangle(0,0,240,80), null);


(lib.navigatorHit = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_48();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.navigatorHit, new cjs.Rectangle(0,0,290,290), null);


(lib.winchMask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_45();
	this.instance.setTransform(-41.45,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.winchMask, new cjs.Rectangle(-41.4,0,83,43), null);


(lib.winchbtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// arrow
	this.instance = new lib.CachedBmp_40();
	this.instance.setTransform(10.5,6.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({y:9.05},0).wait(1));

	// bg
	this.instance_1 = new lib.CachedBmp_41();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_42();
	this.instance_2.setTransform(0,0,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_43();
	this.instance_3.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,47.5,39);


(lib.winchMask2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_29();
	this.instance.setTransform(-41.45,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.winchMask2, new cjs.Rectangle(-41.4,0,83,43), null);


(lib.helmBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"out":0,"over":1,"down":2});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(3));

	// arrow
	this.instance = new lib.CachedBmp_13();
	this.instance.setTransform(42,53.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_14();
	this.instance_1.setTransform(42,57.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).wait(1));

	// circle
	this.instance_2 = new lib.CachedBmp_20();
	this.instance_2.setTransform(-0.7,67.7,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_19();
	this.instance_3.setTransform(-0.35,50.25,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_18();
	this.instance_4.setTransform(0,40.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4,p:{y:40.1}},{t:this.instance_3,p:{y:50.25}},{t:this.instance_2,p:{y:67.7}}]}).to({state:[{t:this.instance_4,p:{y:44}},{t:this.instance_3,p:{y:54.15}},{t:this.instance_2,p:{y:71.6}}]},2).wait(1));

	// bg
	this.instance_5 = new lib.CachedBmp_21();
	this.instance_5.setTransform(0,0,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_22();
	this.instance_6.setTransform(0,0,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_24();
	this.instance_7.setTransform(0,0,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_23();
	this.instance_8.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5}]}).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_8},{t:this.instance_7}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.7,0,73.2,147.5);


(lib.header = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// bg
	this.instance = new lib.CachedBmp_10();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.header, new cjs.Rectangle(0,0,310,50), null);


(lib.meterMask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// N
	this.instance = new lib.CachedBmp_9();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.meterMask, new cjs.Rectangle(0,0,330,13.5), null);


(lib.checkBoxIc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_5();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.checkBoxIc, new cjs.Rectangle(0,0,12,9), null);


(lib.slider = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// sliderDragger
	this.sliderDragger = new lib.sliderDragger();

	this.timeline.addTween(cjs.Tween.get(this.sliderDragger).wait(1));

	// sliderBg
	this.sliderBg = new lib.sliderBg();

	this.timeline.addTween(cjs.Tween.get(this.sliderBg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.slider, new cjs.Rectangle(0,0,46,126), null);


(lib.sails = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// jibSailMirror
	this.jibSailMirror = new lib.jibSailMirror();
	this.jibSailMirror.setTransform(101.2,1,0.9998,0.9998,-0.0009,0,0,1.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.jibSailMirror).wait(1));

	// jibSail
	this.jibSail = new lib.jibSail();
	this.jibSail.setTransform(98.9,0,0.9998,0.9998,0,0,0,1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.jibSail).wait(1));

	// mainSailMirror
	this.mainSailMirror = new lib.mainSailMirror();
	this.mainSailMirror.setTransform(99.3,150.4,1,1,0,0,0,0.7,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainSailMirror).wait(1));

	// mainSail
	this.mainSail = new lib.mainSail();
	this.mainSail.setTransform(99.3,150.4,1,1,0,0,0,0.5,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainSail).wait(1));

	// rudder
	this.rudder = new lib.rudder();
	this.rudder.setTransform(100.4,306.1);

	this.timeline.addTween(cjs.Tween.get(this.rudder).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sails, new cjs.Rectangle(-56.5,-19.3,311.3,405.90000000000003), null);


(lib.sailBoat = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// sails
	this.sails = new lib.sails();
	this.sails.setTransform(0.3,-0.1,1,1,0,0,0,100.3,183.2);

	this.timeline.addTween(cjs.Tween.get(this.sails).wait(1));

	// boat
	this.instance = new lib.boat();
	this.instance.setTransform(0.35,-0.1,1,1,0,0,0,53.8,184);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sailBoat, new cjs.Rectangle(-156.5,-202.6,311.3,405.9), null);


(lib.winchButtons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// bg
	this.instance = new lib.CachedBmp_44();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// btnL_btnR
	this.btnR = new lib.winchbtn();
	this.btnR.setTransform(73.5,22.45,1,1,0,0,0,23.7,19.5);

	this.btnL = new lib.winchbtn();
	this.btnL.setTransform(26.05,22.55,1,1,0,0,180,23.7,19.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btnL},{t:this.btnR}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.winchButtons, new cjs.Rectangle(0,0,99,43.5), null);


(lib.halfCircle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// m
	this.instance = new lib.CachedBmp_37();
	this.instance.setTransform(-9,-7.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// theMask
	this.theMask = new lib.winchMask();
	this.theMask.setTransform(41.1,41.6,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.theMask).wait(1));

	// bg
	this.instance_1 = new lib.CachedBmp_38();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.halfCircle, new cjs.Rectangle(-9,-7.4,100,97.5), null);


(lib.mainWinch = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// buttons_halfCircle_txt
	this.buttons = new lib.winchButtons();
	this.buttons.setTransform(49.6,68.25,1,1,0,0,0,49.6,21.7);

	this.txt = new cjs.Text("24", "17px 'Tahoma'", "#F7F7F7");
	this.txt.name = "txt";
	this.txt.textAlign = "center";
	this.txt.lineHeight = 23;
	this.txt.lineWidth = 21;
	this.txt.parent = this;
	this.txt.setTransform(49.1,19.6);

	this.halfCircle = new lib.halfCircle();
	this.halfCircle.setTransform(49.75,20.8,1,1,0,0,0,41.5,20.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.halfCircle},{t:this.txt},{t:this.buttons}]}).wait(1));

	// bg
	this.instance = new lib.CachedBmp_36();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainWinch, new cjs.Rectangle(-0.7,-7.4,100.7,97.5), null);


(lib.lcd = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// hit
	this.txtDepthHit = new lib.txtHit();
	this.txtDepthHit.setTransform(300,74,1,1,0,0,0,37,29);

	this.txtHdgHit = new lib.txtHit();
	this.txtHdgHit.setTransform(235.05,51.6,0.6757,0.7759,0,0,0,37.1,29.1);

	this.txtWindHit = new lib.txtHit();
	this.txtWindHit.setTransform(171,44.6,1,0.7759,0,0,0,37,29.1);

	this.txtHeelHit = new lib.txtHit();
	this.txtHeelHit.setTransform(105.05,51.55,0.6757,0.7759,0,0,0,37.1,29.1);

	this.txtSpeedHit = new lib.txtHit();
	this.txtSpeedHit.setTransform(40,74,1,1,0,0,0,37,29);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txtSpeedHit},{t:this.txtHeelHit},{t:this.txtWindHit},{t:this.txtHdgHit},{t:this.txtDepthHit}]}).wait(1));

	// txt
	this.txtDepth = new cjs.Text("0000", "30px 'Arial'", "#F7F7F7");
	this.txtDepth.name = "txtDepth";
	this.txtDepth.textAlign = "center";
	this.txtDepth.lineHeight = 36;
	this.txtDepth.lineWidth = 70;
	this.txtDepth.parent = this;
	this.txtDepth.setTransform(300,47);

	this.instance = new lib.CachedBmp_34();
	this.instance.setTransform(263.45,84,0.5,0.5);

	this.txtHdg = new cjs.Text("0000", "20px 'Arial'", "#F7F7F7");
	this.txtHdg.name = "txtHdg";
	this.txtHdg.textAlign = "center";
	this.txtHdg.lineHeight = 24;
	this.txtHdg.lineWidth = 46;
	this.txtHdg.parent = this;
	this.txtHdg.setTransform(235,31);

	this.instance_1 = new lib.CachedBmp_33();
	this.instance_1.setTransform(210,54,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_32();
	this.instance_2.setTransform(138,49,0.5,0.5);

	this.txtWind = new cjs.Text("0000", "25px 'Arial'", "#F7F7F7");
	this.txtWind.name = "txtWind";
	this.txtWind.textAlign = "center";
	this.txtWind.lineHeight = 30;
	this.txtWind.lineWidth = 59;
	this.txtWind.parent = this;
	this.txtWind.setTransform(169.5,20);

	this.instance_3 = new lib.CachedBmp_31();
	this.instance_3.setTransform(80,54,0.5,0.5);

	this.txtHeel = new cjs.Text("0000", "20px 'Arial'", "#F7F7F7");
	this.txtHeel.name = "txtHeel";
	this.txtHeel.textAlign = "center";
	this.txtHeel.lineHeight = 24;
	this.txtHeel.lineWidth = 46;
	this.txtHeel.parent = this;
	this.txtHeel.setTransform(101,31);

	this.instance_4 = new lib.CachedBmp_30();
	this.instance_4.setTransform(3,84,0.5,0.5);

	this.txtSpeed = new cjs.Text("0000", "30px 'Arial'", "#F7F7F7");
	this.txtSpeed.name = "txtSpeed";
	this.txtSpeed.textAlign = "center";
	this.txtSpeed.lineHeight = 36;
	this.txtSpeed.lineWidth = 70;
	this.txtSpeed.parent = this;
	this.txtSpeed.setTransform(40,47);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txtSpeed},{t:this.instance_4},{t:this.txtHeel},{t:this.instance_3},{t:this.txtWind},{t:this.instance_2},{t:this.instance_1},{t:this.txtHdg},{t:this.instance},{t:this.txtDepth}]}).wait(1));

	// bg
	this.instance_5 = new lib.CachedBmp_35();
	this.instance_5.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.lcd, new cjs.Rectangle(0,0,340,128), null);


(lib.winchButtons2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// bg
	this.instance = new lib.CachedBmp_28();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// btnL_btnR
	this.btnR = new lib.winchbtn();
	this.btnR.setTransform(73.5,22.45,1,1,0,0,0,23.7,19.5);

	this.btnL = new lib.winchbtn();
	this.btnL.setTransform(26.05,22.55,1,1,0,0,180,23.7,19.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btnL},{t:this.btnR}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.winchButtons2, new cjs.Rectangle(0,0,99,43.5), null);


(lib.halfCircle2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// m
	this.instance = new lib.CachedBmp_37();
	this.instance.setTransform(-9,-7.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// theMask
	this.theMask = new lib.winchMask2();
	this.theMask.setTransform(41.1,41.6,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.theMask).wait(1));

	// bg
	this.instance_1 = new lib.CachedBmp_38();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.halfCircle2, new cjs.Rectangle(-9,-7.4,100,97.5), null);


(lib.jibWinch = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// buttons_halfCircle_txt
	this.buttons = new lib.winchButtons2();
	this.buttons.setTransform(49.6,68.25,1,1,0,0,0,49.6,21.7);

	this.txt = new cjs.Text("24", "17px 'Tahoma'", "#F7F7F7");
	this.txt.name = "txt";
	this.txt.textAlign = "center";
	this.txt.lineHeight = 23;
	this.txt.lineWidth = 21;
	this.txt.parent = this;
	this.txt.setTransform(49.1,19.6);

	this.halfCircle = new lib.halfCircle2();
	this.halfCircle.setTransform(49.75,20.8,1,1,0,0,0,41.5,20.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.halfCircle},{t:this.txt},{t:this.buttons}]}).wait(1));

	// bg
	this.instance = new lib.CachedBmp_36();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.jibWinch, new cjs.Rectangle(-0.7,-7.4,100.7,97.5), null);


(lib.helmButtons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// btnL_btnR
	this.btnL = new lib.helmBtn();
	this.btnL.setTransform(36.15,73.6,0.9996,1,0,0,180,36.3,73.6);

	this.btnR = new lib.helmBtn();
	this.btnR.setTransform(108.75,73.6,1,1,0,0,0,36.3,73.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btnR},{t:this.btnL}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.helmButtons, new cjs.Rectangle(0,0,145,147.5), null);


(lib.helm = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// sep
	this.instance = new lib.CachedBmp_11();
	this.instance.setTransform(71.6,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// buttons
	this.buttons = new lib.helmButtons();
	this.buttons.setTransform(78.05,78.25,1,1,0,0,0,72.5,73.6);

	this.timeline.addTween(cjs.Tween.get(this.buttons).wait(1));

	// bg
	this.instance_1 = new lib.CachedBmp_12();
	this.instance_1.setTransform(-25.8,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.helm, new cjs.Rectangle(-25.8,-0.5,205,157), null);


(lib.eMeterHolder = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// m
	this.instance = new lib.CachedBmp_7();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// theMask
	this.theMask = new lib.meterMask();
	this.theMask.setTransform(0,8.8,1,1,0,0,0,0,6.8);

	this.timeline.addTween(cjs.Tween.get(this.theMask).wait(1));

	// bg
	this.instance_1 = new lib.CachedBmp_8();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.eMeterHolder, new cjs.Rectangle(0,0,330,19), null);


(lib.eMeter = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.eMeterHolder = new lib.eMeterHolder();
	this.eMeterHolder.setTransform(165.55,8.3,0.85,1,0,0,0,165.6,6.8);

	this.timeline.addTween(cjs.Tween.get(this.eMeterHolder).wait(1));

	// bg
	this.instance = new lib.CachedBmp_6();
	this.instance.setTransform(-10,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.eMeter, new cjs.Rectangle(-10,0,350,50), null);


(lib.checkBox = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"out":0,"over":1});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// checkBoxIc
	this.checkBoxIc = new lib.checkBoxIc();
	this.checkBoxIc.setTransform(10.5,10.05,1,1,0,0,0,6,4.5);

	this.timeline.addTween(cjs.Tween.get(this.checkBoxIc).wait(2));

	// hit
	this.instance = new lib.CachedBmp_2();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// bg
	this.instance_1 = new lib.CachedBmp_83();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_84();
	this.instance_2.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,100,20);


(lib.wind = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"out":0,"over":1});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// slider
	this.slider = new lib.slider();
	this.slider.setTransform(0,-37,1,1,0,0,0,23,63);

	this.timeline.addTween(cjs.Tween.get(this.slider).wait(2));

	// windArrow
	this.instance = new lib.CachedBmp_80();
	this.instance.setTransform(-9.5,-142,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_81();
	this.instance_1.setTransform(-9.5,-142,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23,-142,46,168);


(lib.navigator = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// sailBoat_wind_notifier
	this.notifierGybing = new lib.notifierGybing();
	this.notifierGybing.setTransform(145.6,194.35,0.62,0.62,0,0,0,120.1,40.1);
	this.notifierGybing.shadow = new cjs.Shadow("rgba(0,0,0,1)",0,3,5);

	this.notifier = new lib.notifier();
	this.notifier.setTransform(145.6,145.1,0.62,0.62,0,0,0,120.1,40.1);
	this.notifier.shadow = new cjs.Shadow("rgba(0,0,0,1)",0,3,5);

	this.notifierTacking = new lib.notifierTacking();
	this.notifierTacking.setTransform(145.6,95.85,0.62,0.62,0,0,0,120.1,40.1);
	this.notifierTacking.shadow = new cjs.Shadow("rgba(0,0,0,1)",0,3,5);

	this.wind = new lib.wind();
	this.wind.setTransform(144.95,145,0.9996,0.9996,60.0002);

	this.sailBoat = new lib.sailBoat();
	this.sailBoat.setTransform(145.05,145.05,0.55,0.55,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.sailBoat},{t:this.wind},{t:this.notifierTacking},{t:this.notifier},{t:this.notifierGybing}]}).wait(1));

	// navigatorHit_display
	this.navigatorHit = new lib.navigatorHit();
	this.navigatorHit.setTransform(145,145,1,1,0,0,0,145,145);

	this.instance = new lib.CachedBmp_46();
	this.instance.setTransform(35.95,26.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.navigatorHit}]}).wait(1));

	// bg
	this.instance_1 = new lib.CachedBmp_47();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.navigator, new cjs.Rectangle(0,0,290,290), null);


// stage content:
(lib.Simulator = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		////////////////////////////////////////////////////////////////////////////////
		/// Base
		
		// in order to have a pointer cursor on MovieClips with their "cursor" property
		// set to "pointer"
		stage.enableMouseOver();
		
		// To enable touch interaction on mobile devices
		createjs.Touch.enable(stage, true, false);
		
		
		
		
		////////////////////////////////////////////////////////////////////////////////
		/// Initialize the Document Class
		
		// We can edit our external JS file, and then run "Test Movie" of our FLA file,
		// so that Adobe Animate can copy our JS file from "_core" to "libs" directory!
		// Why such copying thing happens by Adobe Animate? Because we have set our
		// external JS file as an included file here on the "Actions" panel.
		
		// The following is included in the "_core/SimulatorCore.js". We give "this" to
		// our factory function so that we can have access to the root from there too.
		window.initSimulator(createjs, stage, this);
		
		
		
		
		////////////////////////////////////////////////////////////////////////////////
		/// A workaround to access root from an external JS file
		
		//function loadScript(url) {
		//    var body = document.getElementsByTagName('body')[0];
		//    var script = document.createElement('script');
		//    script.type = 'text/javascript';
		//    script.src = url;
		//    body.appendChild(script);
		//}
		//
		//loadScript('_core/simulator.js');
		//
		//var root = this; // now the external JS file will have access to root
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.tooltip = new lib.tooltip();
	this.tooltip.setTransform(15,37);
	this.tooltip.shadow = new cjs.Shadow("rgba(0,0,0,1)",0,3,5);

	this.eMeter = new lib.eMeter();
	this.eMeter.setTransform(30.6,549.5,1,1,0,0,0,0.6,9.5);

	this.notifierFix = new lib.notifierFix();
	this.notifierFix.setTransform(25,519.3,1,1,0,0,0,0,9.3);

	this.checkBox = new lib.checkBox();
	this.checkBox.setTransform(273.45,520,1,1,0,0,0,10,10);

	this.helm = new lib.helm();
	this.helm.setTransform(194.6,478.25,0.62,0.62,0,0,0,77.6,75.5);

	this.jibWinch = new lib.jibWinch();
	this.jibWinch.setTransform(292.6,423.7,1,1,0,0,0,27.6,13.8);

	this.mainWinch = new lib.mainWinch();
	this.mainWinch.setTransform(52.6,423.7,1,1,0,0,0,27.6,13.8);

	this.navigator = new lib.navigator();
	this.navigator.setTransform(195,275,1,1,0,0,0,145,145);

	this.header = new lib.header();
	this.header.setTransform(190,35,1,1,0,0,0,150,25);

	this.lcd = new lib.lcd();
	this.lcd.setTransform(195,95,1,1,0,0,0,170,50);

	this.instance = new lib.CachedBmp_82();
	this.instance.setTransform(15,35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.lcd},{t:this.header},{t:this.navigator},{t:this.mainWinch},{t:this.jibWinch},{t:this.helm},{t:this.checkBox},{t:this.notifierFix},{t:this.eMeter},{t:this.tooltip}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(210,315,165,280);
// library properties:
lib.properties = {
	id: 'C8DD58C0E95BAE4ABF032542D82761E7',
	width: 390,
	height: 610,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"Simulator/images/Simulator_atlas_.png?1615476696107", id:"Simulator_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C8DD58C0E95BAE4ABF032542D82761E7'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;